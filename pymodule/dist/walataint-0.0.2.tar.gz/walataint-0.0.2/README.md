# WALA-Taint Python 
This package provides wata-taint primitives for writing function summaries.